// procltx.cpp
// Name: Shreyas Kumar Jaiswal
// Roll No: 2301CS52
// CS3104 Compiler Lab, Autumn 2025 - Assignment 5
#include <iostream>
using namespace std;

extern "C" void yylex();

int main() {
  yylex(); 
  return 0;
}
